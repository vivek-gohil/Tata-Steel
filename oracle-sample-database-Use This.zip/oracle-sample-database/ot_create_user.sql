
-- create new user
CREATE USER OT IDENTIFIED BY yourpassword;

-- grant priviledges
GRANT CONNECT, RESOURCE, DBA TO OT;